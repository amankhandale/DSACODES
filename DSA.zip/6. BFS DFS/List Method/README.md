Adjacency list method
